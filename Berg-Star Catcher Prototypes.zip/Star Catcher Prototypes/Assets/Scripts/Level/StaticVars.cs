﻿public class StaticVars  {

	public static float distance = 50;
	public static float nextSectionPosition = 50;

}